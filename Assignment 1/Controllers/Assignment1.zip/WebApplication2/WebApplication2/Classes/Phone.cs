﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication2.Classes
{
    public class Phone
    {
        

        //constructor
        public Phone()
        {
            //date set
            DateReleased = DateTime.Now;
     
        }

        //properties
        
        public int id { get; set; }
        public string PhoneName { get; set; }
        public string manufacturer { get; set; }
        public DateTime DateReleased { get; set; }
        public int MSRP { get; set; }
        public double ScreenSize { get; set; }
        
       
    }
}